READ ME file for COMPSYN and ISOSYN applications

This folder/directory contains fortran and (possibly) 'include' files
needed to build a single COMPSYN or ISOSYN application.  The main program
has the same name as the containing folder.  To produce the executable
file you need only the files in this folder/directory and the object library
produced from the fortran files in the LIBRARY folder/directory.
Compile all files in this folder/directory and link to the LIBRARY object
library.
