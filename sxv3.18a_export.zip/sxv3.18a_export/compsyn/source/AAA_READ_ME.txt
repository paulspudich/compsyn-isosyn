READ ME: Spudich and Xu

Contents of ~compsyn\source

The source folder is made up of sub-
folders olson, seeslo, slip, tfault and xolson. Each of them can be built into 
an independent application. The names of main programs are the same as the 
corresponding folder names. 

All files in the Library folder/directory should be compiled and placed
into an object library.  There are no main programs in the Library.  
All applications in the Compsyn package call subroutines
in the library, so when linking any application you should link to the 
object library you have created from the Library files.


