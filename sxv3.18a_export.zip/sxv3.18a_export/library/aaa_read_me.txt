READ ME file for COMPSYN and ISOSYN Library files

This folder/directory contains 52 .for and 1 .inc files.  These files 
should all be compiled, and all resulting object files should be linked 
into an object library.  When you create any of the executable files
in either the COMPSYN or ISOSYN packages, you should link to the 
object library you have created from the contents of this directory.
