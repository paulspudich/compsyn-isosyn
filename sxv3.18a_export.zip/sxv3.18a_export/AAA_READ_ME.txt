2/19/2012: 

On 2/17 Larry and I created sxv3.17b which was identical to sxv3.17a except that 
it contains a /bin which was compiled with the gfortran compiler. 

Today I renamed sxv3.17b to sxv3.18a because the '18' will imply it is the latest
fortran.  The 'b' implied that only the packaging was changed.  At present 18a fortran
is identical to 17a fortan, but I want there to be only one 'latest version' for the fortran. 
I should create two different bins in the sxv3.18a folder - one compiled by intel complier
and one compiled by gfortran. 



-----------------begin old read me-------------------
READ ME: Spudich and Xu sxv3.14d
8 January 2007

(Please note the section QUICK START at the bottom of this file)

NOTE - if you have older versions (e.g. sxv3.11), you should replace it with 
the complete sxv3.14d package.  Numerous fortran files have changed, and you 
are unlikely to be able to substitute individual files successfully. 


Folder sxv3.14d

This folder contains the following items:

AAA_READ_ME.TXT - this file
compsyn folder - contains compsyn fortran and test examples
isosyn folder - contains isosyn fortran and a test example
library folder - contains fortran subroutines used by compsyn and isosyn
dos_digfort_compile.bat - example dos script to compile and link codes using 
		Digital Visual Fortran compiler
unix_absoft_compile.bat - example unix script to compile and link codes using
		Absoft fortran compiler
unix_intel_compile.bat - example unix script to compile and link codes using
		Intel fortran compiler

1)	The Compsyn folder/directory contains the source files, 
documentation, and two test examples for the COMPSYN package. 

2)	The Isosyn folder/directory contains the source files, 
documentation, and one test example for the ISOSYN package. 

3)	The Library folder contains all fortran for a set of subroutines
that should be compiled into an object library, to which all
main programs will need to link.

4)	dos_digfort_compile.bat -  
This is a DOS script that compiles and links all executables in both 
packages.  (DigFort is the Digital Visual Fortran Compiler). If you have
a different compiler, you will need to modify this script, but the
script will give you the general idea of how to compile and link the
codes.  Also, you will have to redefine the %TOP%  variable to 
point to the directory in which this file AAA_READ_ME.txt resides.  You
will have to define the %BIN% variable to point to the directory where you 
want the executable files placed.  Be careful to implement the correct switches 
in the fortran compiler.  Use our switches as a guide.  Note that the current
dimension statements in the codes might create arrays that are too large for your
computer's RAM.  See the documentation for instructions on resetting the array
dimensions. This script will also add the location of the executable files 
to your path.

5)	unix_*_compile.bat -
These are unix (tcsh) scripts that compile and link all executables in
both packages.  They currently set up to use the Absoft fortran
Complier or the Intel fortran compiler.  You will have to change them 
to use your compiler.  Be careful to implement the correct switches in the 
fortran compiler.  Use our switches as a guide.  You will have to 
redefine the TOP environmental  variable to 
point to the directory in which this file AAA_READ_ME.txt resides.  You
will have to redefine the BIN environmental variable to point to the directory 
where you want the executable files placed.  Be sure to add this directory to your
PATH, so that the example scripts work.  Note that the current
dimension statements in the codes might create arrays that are too large for your
computer's RAM.  See the documentation for instructions on resetting the array
dimensions. 


1.1  Isosyn Package

For the package Isosyn, its source files, manual and a test 
example are provided in three folders named source, manual, 
and example, respectively. In the source folder you will further find six 
sub-folders called spred8, fault8, quake8, display8, seeall8 and addstf8. 
They actually form independent source code groups, each of which can be 
built into an independent application. The names of 
folders are just the names of their main programs, and other files are its 
subroutines. 

In the example folder, there are a set of input data files, spred8p.s8d, 
spred8s.s8d, fault8p.f8d, fault8s.f8d, quake8.q8d, provided for you to start 
this software package, some intermediate files, spred8p.s8o, spred8s.s8o 
spred8p.s8p, spred8s.s8p, fault8p.f8o, fault8s.f8o, fault8p.f8p, fault8s.f8p, 
quake8.q8p, quake8.q8s and addstf8.a8p, produced by the related procedures 
for you to compare with to find possible reason if you run into some 
problems, and final output files, addstf801.xv, addstf801.yv, addstf801.zv, 
display8.ps, which you should get after you run these package 
properly. 

In the manual folder, you will find the manual for Isosyn package, which 
introduces its theoretical background and usage. The manual is an Adobe 
PDF format file.  This is the manual for version sxv3.11, and is slightly 
out of date.

1.2 Compsyn Package

Similarly to the Isosyn package, for CompSyn the source files, 
manual and two test examples are offered in three folders, source, 
manual, example1, and example2. Further, the source-files is made up of sub-
folders olson, seeslo, slip, tfault and xolson. Each of them can be built into 
an independent application. The names of main programs are the same as the 
corresponding folder names. 

In the example1 folder, there are input data files olson.old, tfault.tfd 
and slip.sld, provided for you to start this software package with.

In the example2 folder, there are input data files bouchon1.old, bouchon2.old,
bouchon1.tfd, and bouchon1.sld, provided for you to start this software package 
with.

In the manual folder, you will find the manual for Compsyn package, which 
introduces its theoretical background and usage. The manual is prepared in 
Adobe PDF format. This is the manual for version sxv3.11, and is slightly 
out of date.


1.3  The Library

All files in the Library folder/directory should be compiled and placed
into an object library.  There are no main programs in the Library.  
All applications in both the Isosyn and Compsyn packages call subroutines
in the library, so when linking any application you should link to the 
object library you have created from the Library files. The *_compile.bat 
scripts should automatically compile the library and create an object library. 

2 How to Install

Please see Quick Start below.


3  How to Execute

To execute either package, it is best to set your working directory to 
be a directory containing the example input files.  Please read the read-me 
files in each example directory for instructions on how to run the 
examples.


--------------------------------------------------------------------------
QUICK START
-----------

We can't guarantee that the following will always work, because we are not 
very good at either dos or unix, but the following might work for you.  


If you use the Digital Visual Fortran compiler on DOS, or if you use the Absoft
or Intel Fortran compilers on unix / linux, with luck 
you can quickly compile, link, and run all the examples in these packages by 
following these instructions.  If you do not use these compilers and DOS, the
scripts used below will be a useful guide to proper compilation, linking, and exection of the programs.

Steps:

-1. Expand sxv3.14b.zip into some directory on your computer, which here we assume will be
/guk/stuff/sxv3.14b


0.    Modify /guk/stuff/sxv3.14b.bat to set TOP :

unix/tcsh:      setenv TOP "/guk/stuff/sxv3.14d"
dos:            set TOP=\guk\stuff\sxv3.14d

    Modify /guk/stuff/sxv3.14b.bat to set BIN to point to the directory in 
which you want your executables placed.  Here we assume it is /guk/bin, but 
you can make it anything you want

unix/tcsh:      setenv BIN "/guk/bin"
dos:            set TOP=\guk\bin

Our dos compile script will automatically append BIN to your path, but on unix you must 
manually change your PATH environmental variable to include BIN.   

1.	open a terminal window and cd to the TOP directory (in this 
example /guk/stuff/sxv3.14d)

2.	execute the appropriate *_compile.bat (if you have one of these 
compilers; if you don't, examine one of these scripts and write a 
replacement that uses your compiler). These scripts will compile and link all 
main programs of both compsyn and isosyn.  It will place all .exe files
in the BIN folder you have specified (in this example /guk/bin). It will modify 
your path statement to include the BIN folder.

3.	cd /guk/stuff/sxv3.14d/isosyn/example - change your working directory to this example
folder for the isosyn package.  Type "olson" (without the quotes) to see if the executables are
in your path.  If program olson starts, kill it (control-C). It is in your path and all is
well.  If olson does not start, modify your path to include the directory containing olson 
and the other executables.  

4.	execute run_all.bat - This script is set up to run most of the 
isosyn programs and generate example output.  After successful execution of this
script, you will find two .ps files in the folder, display800.ps and display801.ps. 
display800.ps is the postscript file showing example seismograms that was provided
with the isosyn package; display801.ps shows the example seismograms you just computed.
These plots should be identical.  WARNING - when you execute run_all.bat, you will 
overwrite all example output files that came with the isosyn package, i.e. your computed
output will overwrite all *.x*, *.y*, *.z*, *.*p, *.*o, *.*r.  This is not a big problem 
because you still have them in the zip file.  This test will take about 1s to run and
use about 0.5 Mb of disk space.  You can view the postscript files with your own 
postscript viewer.  Calculated seismic time series are in the *.x*, *.y*, and *.z*
ascii files. 

6.	cd /guk/stuff/sxv3.14d/compsyn/example1 - change your working directory to this example
folder for the compsyn package.

7.	execute run_all.bat - This script is set up to run the complete set of 
compsyn programs and generate example output.  After successful execution of this
script, you will find two .ps files in the folder, seeslo00.ps and seeslo01.ps. 
seeslo00.ps is the postscript file showing example seismograms that was provided
with the compsyn package; seeslo01.ps shows the example seismograms you just computed.
These plots should be identical.  WARNING - when you execute run_all.bat, you will 
overwrite all example output files that came with the isosyn package, i.e. your computed
output will overwrite all *.x*, *.y*, *.z*, *.*p, *.*o.  This is not a big problem 
because you still have them in the zip file.  Running this example will take about 1 minute and 
use about 60 Mb of disk space.  You can view the postscript files with your own 
postscript viewer.  Calculated seismic time series are in the *.x*, *.y*, and *.z*
ascii files. 


8.	cd /guk/stuff/sxv3.14d/compsyn/example2 - change your working directory to this example
folder for the compsyn package.

9.	execute run_all.bat - This script is set up to run the complete set of 
compsyn programs and generate example output.  After successful execution of this
script, you will find two .ps files in the folder, seeslo00.ps and seeslo01.ps. 
seeslo00.ps is the postscript file showing example seismograms that was provided
with the compsyn package; seeslo01.ps shows the example seismograms you just computed.
These plots should be identical.  WARNING - when you execute run_all.bat, you will 
overwrite all example output files that came with the isosyn package, i.e. your computed
output will overwrite all *.x*, *.y*, *.z*, *.*p, *.*o.  This is not a big problem 
because you still have them in the zip file.  Running this example will take about 3 minutes and 
use about 260 Mb of disk space.  You can view the postscript files with your own 
postscript viewer.  Calculated seismic time series are in the *.x*, *.y*, and *.z*
ascii files. 

