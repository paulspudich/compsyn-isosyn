README: Spudich and Xu, v3.10

In ~isosyn\source

In the source folder you will find six 
sub-folders called spred8, fault8, quake8, display8, seeall8 and addstf8. 
They actually form independent source code groups, each of which can be 
built into an independent application. The names of 
folders are just the names of their main programs, and other files are its 
subroutines. 

All files in the Library folder/directory should be compiled and placed
into an object library.  There are no main programs in the Library.  
All applications in the isosyn package call subroutines
in the library, so when linking any application you should link to the 
object library you have created from the Library files.
