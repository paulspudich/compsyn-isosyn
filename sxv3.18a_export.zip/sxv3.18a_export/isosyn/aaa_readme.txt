READ ME: Spudich and Xu v1.1

Isosyn Folder

For the package Isosyn, its source files, manual and a test 
example are provided in three folders named source, manual, 
and example, respectively. In the source folder you will further find six 
sub-folders called spred8, fault8, quake8, display8, seeall8 and addstf8. 
They actually form independent source code groups, each of which can be 
built into an independent application. The names of 
folders are just the names of their main programs, and other files are its 
subroutines. 

In the example folder, there are a set of input data files and output files
provided for an example calculation.  Also provided is a DOS script run_all.bat
which will execute the entire test problem.  Please read the read-me file in 
the example folder to see how to execute run_all.bat.

In the manual folder, you will find the manual for Isosyn package, which 
introduces its theoretical background and usage. The manual is prepared in 
forms of  *.doc(MsWord format) and Adobe pdf.


